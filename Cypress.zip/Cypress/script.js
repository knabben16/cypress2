document.getElementById('cadastroForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const confirmarSenha = document.getElementById('confirmarSenha').value;
    const mensagem = document.getElementById('mensagem');

    if (!nome || !email || !senha || !confirmarSenha) {
        mensagem.textContent = 'Todos os campos são obrigatórios.';
        mensagem.className = 'mensagem erro';
        return;
    }

    if (senha !== confirmarSenha) {
        mensagem.textContent = 'As senhas não correspondem.';
        mensagem.className = 'mensagem erro';
        return;
    }

    mensagem.textContent = 'Cadastro realizado com sucesso!';
    mensagem.className = 'mensagem sucesso';
    document.getElementById('cadastroForm').reset();
});
