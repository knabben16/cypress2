describe('Formulário de Cadastro', () => {
  beforeEach(() => {
      cy.visit('http://127.0.0.1:5500/index.html');
  });

  it('deve exibir mensagem de erro para campos obrigatórios vazios', () => {
      cy.get('button').click();
      cy.get('#mensagem').should('contain', 'Todos os campos são obrigatórios.');
  });

  it('deve exibir mensagem de erro para senhas diferentes', () => {
      cy.get('#nome').type('João');
      cy.get('#email').type('joao@example.com');
      cy.get('#senha').type('senha123');
      cy.get('#confirmarSenha').type('senha456');
      cy.get('button').click();
      cy.get('#mensagem').should('contain', 'As senhas não correspondem.');
  });

  it('deve exibir mensagem de sucesso para cadastro bem-sucedido', () => {
      cy.get('#nome').type('João');
      cy.get('#email').type('joao@example.com');
      cy.get('#senha').type('senha123');
      cy.get('#confirmarSenha').type('senha123');
      cy.get('button').click();
      cy.get('#mensagem').should('contain', 'Cadastro realizado com sucesso!');
  });
});
